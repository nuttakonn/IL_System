﻿using ILSCREEN_MSSQL_API.DataAccess.Interfaces;
using ILSCREEN_MSSQL_API.Models;
using ILSCREEN_MSSQL_API.Services.Interfaces;
using System.Data;

namespace ILSCREEN_MSSQL_API.Services
{
    public class AccountService : IAccountService
    {
        protected readonly IDataCenter _dc;
        public AccountService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> GetViewVendorMaster(string searchBy, string searchValue)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC {_dc.SchemaDB()?.IL}.[sp_GetViewVendorMaster] '{searchBy}','{searchValue}'";
                var result = await _dc.Get<List<ViewVendorMasterModel>>(strCommand, CommandType.Text);
                if (result.success || result.message.Contains("Data not found"))
                {
                    response.status = 200;
                    response.success = true;
                    response.data = result.data;
                }
                else
                    response.status = 400;
                response.message = result.message;
            }
            catch (Exception ex)
            {
                response.error = ex;
                response.message = ex.Message;
            }

            return response;
        }
    }
}
