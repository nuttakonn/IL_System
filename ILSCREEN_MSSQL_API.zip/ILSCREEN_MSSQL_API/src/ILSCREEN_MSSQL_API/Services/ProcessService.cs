﻿using ILSCREEN_MSSQL_API.DataAccess.Interfaces;
using ILSCREEN_MSSQL_API.Models;
using ILSCREEN_MSSQL_API.Services.Interfaces;
using System.Data;

namespace ILSCREEN_MSSQL_API.Services
{
    public class ProcessService : IProcessService
    {
        private readonly IDataCenter _dataCenter;
        public ProcessService(IDataCenter dataCenter)
        {
            _dataCenter = dataCenter;
        }
        public async Task<ResponseModel> GetMonitorCaseUnsign(string vendor)
        {
            var response = new ResponseModel();
            try
            {
                string strCommand = $@"EXEC [AS400DB01].[ILOD0001].[sp_GetPatchAutoSign]
                            N'02',
		                    N'{vendor}',
		                    NULL";
                var result = await _dataCenter.Get<List<MonitorCaseUnsign>>(strCommand, CommandType.Text);

                if (result.success)
                {
                    response.status = 200;
                    response.success = true;
                    response.message = result.data.Any() ? "Data retrieved successfully." : "Data not found.";
                    response.data = result.data ?? new List<MonitorCaseUnsign>();
                }
                else
                {
                    if (result.data == null || !result.data.Any())
                    {
                        response.status = 200;      
                        response.success = true;    
                        response.message = "Data not found.";
                        response.data = new List<MonitorCaseUnsign>();
                    }
                    else
                    {
                        response.status = 500;
                        response.success = false;
                        response.message = result.message ?? "An error occurred while fetching data.";
                        response.data = null;
                    }
                }
            }
            catch (Exception ex)
            {
                response.status = 500;
                response.success = false;
                response.message = $"Exception: {ex.Message}";
                response.data = null;
            }
            return response;

        }
        public async Task<ResponseModel> GetVendorListMonitorCaseUnsign()
        {
            var response = new ResponseModel();
            try
            {
                string strCommand = $@"select FORMAT(p10ven,'000000000000') as P10VEN, P10NAM, P10FIL 
                             from AS400DB01.ILOD0001.ilms10 WITH (NOLOCK)
                             where p10brn = 001 and p10del = '' 
                             and FORMAT(GETDATE(),'yyyyMMdd','th-TH') between p10fjd and p10edt 
                             and exists (select * from AS400DB01.ILOD0001.ilmd10 WITH (NOLOCK) where p10ven = d10ven and d10apt = '01') 
                             order by p10nam, p10ven ";
                var result = await _dataCenter.Get<List<VendorList>>(strCommand, CommandType.Text);

                if (result.success)
                {
                    response.status = 200;
                    response.success = true;
                    response.message = result.data.Any() ? "Data retrieved successfully." : "No data found.";
                    response.data = result.data ?? new List<VendorList>();
                }
                else
                {
                    if (result.data == null || !result.data.Any())
                    {
                        response.status = 200;
                        response.success = true;
                        response.message = "Data not found.";
                        response.data = new List<VendorList>();
                    }
                    else
                    {
                        response.status = 500;
                        response.success = false;
                        response.message = result.message ?? "An error occurred while fetching data.";
                        response.data = null;
                    }
                }
            }
            catch (Exception ex)
            {
                response.status = 500;
                response.success = false;
                response.message = $"Exception: {ex.Message}";
                response.data = null;
            }
            return response;
        }
    }
}
