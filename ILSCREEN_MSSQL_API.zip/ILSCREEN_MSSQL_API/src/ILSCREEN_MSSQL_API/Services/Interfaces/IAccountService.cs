﻿using ILSCREEN_MSSQL_API.Models;

namespace ILSCREEN_MSSQL_API.Services.Interfaces
{
    public interface IAccountService
    {
        Task<ResponseModel> GetViewVendorMaster(string searchBy, string searchValue);

    }
}
