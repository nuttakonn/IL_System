﻿using ILSCREEN_MSSQL_API.Models;

namespace ILSCREEN_MSSQL_API.Services.Interfaces
{
    public interface IProcessService
    {
        public Task<ResponseModel> GetMonitorCaseUnsign(string vendor);
        public Task<ResponseModel> GetVendorListMonitorCaseUnsign();

    }
}