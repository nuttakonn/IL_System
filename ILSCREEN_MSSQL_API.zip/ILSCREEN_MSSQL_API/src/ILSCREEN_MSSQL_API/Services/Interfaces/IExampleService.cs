﻿using ILSCREEN_MSSQL_API.Models;

namespace ILSCREEN_MSSQL_API.Services.Interfaces
{
    public interface IExampleService
    {
        Task<ResponseModel> GetExample(string idNo);

    }
}
