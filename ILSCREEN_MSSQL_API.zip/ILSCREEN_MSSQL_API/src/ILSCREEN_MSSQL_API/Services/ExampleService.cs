﻿using ILSCREEN_MSSQL_API.DataAccess.Interfaces;
using ILSCREEN_MSSQL_API.Models;
using ILSCREEN_MSSQL_API.Services.Interfaces;
using System.Data;

namespace ILSCREEN_MSSQL_API.Services
{
    public class ExampleService : IExampleService
    {
        protected readonly IDataCenter _dc;
        public ExampleService(IDataCenter dc) => _dc = dc;

        public async Task<ResponseModel> GetExample(string idNo)
        {
            var response = new ResponseModel();
            try
            {
                var strCommand = @$"EXEC [AccountingInfo].[spGetContractReceiveTransaction] '{_dc.SchemaDB()?.ReceiveInfo}','{_dc.SchemaDB()?.GeneralInfo}'";
                var result = await _dc.Get<List<object>>(strCommand, CommandType.Text);
                if (result.success)
                {
                    response.success = true;
                    response.status = 200;
                    response.message = result.message;
                    response.data = result.data;
                }
                else response.message = result.message;
            }
            catch (Exception ex)
            {
                response.message = ex.Message;
            }
            return response;
        }
    }
}
