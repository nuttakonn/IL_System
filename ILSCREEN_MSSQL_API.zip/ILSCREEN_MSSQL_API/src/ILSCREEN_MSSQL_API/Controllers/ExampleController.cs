﻿using ILSCREEN_MSSQL_API.Models;
using ILSCREEN_MSSQL_API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ILSCREEN_MSSQL_API.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ExampleController : ControllerBase
    {
        protected readonly IExampleService _exSV;
        public ExampleController(IExampleService exSV) => _exSV = exSV;

        [HttpPost("GetExample", Name = "GetExample")]
        public async Task<IActionResult> GetExample(string idNo)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                var response = await _exSV.GetExample(idNo);
                returnResponse.success = response.success;
                returnResponse.status = response.status;
                returnResponse.data = response.data;
                returnResponse.message = response.message;
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                return await Task.FromResult(BadRequest($"{ex.Message} - {ex.StackTrace}"));
            }
        }
    }
}
