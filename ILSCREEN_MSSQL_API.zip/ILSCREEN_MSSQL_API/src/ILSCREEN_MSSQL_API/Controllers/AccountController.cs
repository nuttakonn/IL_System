﻿using ILSCREEN_MSSQL_API.Models;
using ILSCREEN_MSSQL_API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ILSCREEN_MSSQL_API.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        protected readonly IAccountService _acSV;
        public AccountController(IAccountService acSV) => _acSV = acSV;

        [HttpGet("GetViewVendorMaster", Name = "GetViewVendorMaster")]
        public async Task<IActionResult> GetViewVendorMaster(string searchBy, string searchValue)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _acSV.GetViewVendorMaster(searchBy, searchValue);
                return await Task.FromResult(Ok(returnResponse));
            }
            catch (Exception ex)
            {
                return await Task.FromResult(BadRequest($"{ex.Message} - {ex.StackTrace}"));
            }
        }
    }
}
