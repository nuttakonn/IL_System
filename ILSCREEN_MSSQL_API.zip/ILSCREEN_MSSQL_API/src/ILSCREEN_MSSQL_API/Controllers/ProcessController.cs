﻿using ILSCREEN_MSSQL_API.Models;
using ILSCREEN_MSSQL_API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Linq; 


namespace ILSCREEN_MSSQL_API.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ProcessController : ControllerBase
    {
        private readonly IProcessService _processService;
        public ProcessController(IProcessService processService)
        {
            _processService = processService;
        }
        [HttpGet("GetMonitorCaseUnsign", Name = "GetMonitorCaseUnsign")]
        public async Task<IActionResult> GetMonitorCaseUnsign(string vendor)
        {
            try
            {
                var result = await _processService.GetMonitorCaseUnsign(vendor);
                if (result.success)
                {
                    var dataList = result.data as List<MonitorCaseUnsign>;
                    if (dataList == null || !dataList.Any())
                        return NotFound(new { success = true, message = "Data not found." });
                    
                    return Ok(result);
                }
                else
                {
                    return StatusCode(500, result);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "An error occurred.", detail = ex.Message });
            }
        }
        [HttpGet("GetVendorListMonitorCaseUnsign", Name = "GetVendorListMonitorCaseUnsign")]
        public async Task<IActionResult> GetVendorListMonitorCaseUnsign()
        {
            try
            {
                var result = await _processService.GetVendorListMonitorCaseUnsign();
                if (result.success)
                {
                    var dataList = result.data as List<VendorList>;
                    if (dataList == null || !dataList.Any())
                        return NotFound(new { success = true, message = "Data not found." });

                    return Ok(result);
                }
                else
                {
                    return StatusCode(500, result);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "An error occurred.", detail = ex.Message });
            }
        }
    }
}
