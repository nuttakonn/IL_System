﻿using ILSCREEN_MSSQL_API.Common.Extensions;
using ILSCREEN_MSSQL_API.Common.Interfaces;
using ILSCREEN_MSSQL_API.DataAccess.Interfaces;
using ILSCREEN_MSSQL_API.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Win32.SafeHandles;
using StackExchange.Redis;
using System.Collections;
using System.Data;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace ILSCREEN_MSSQL_API.DataAccess
{
    public class DataCenter : IDataCenter
    {
        private string _conStr;
        private readonly string _readonly = "ReadOnly";
        private readonly string _readwrite = "ReadWrite";
        private readonly string _domain;
        private readonly IConnectionMultiplexer _redis;
        private readonly IHttpContextAccessor _context;
        private readonly ICipher _cipher;
        const int LOGON32_PROVIDER_DEFAULT = 0;
        const int LOGON32_LOGON_INTERACTIVE = 2;
        public DataCenter(IConfiguration config, IConnectionMultiplexer redis, IHttpContextAccessor context, ICipher cipher)
        {
            _redis = redis;
            _cipher = cipher;
            _context = context;
            _conStr = config.GetConnectionString("DbContext") ?? string.Empty;
            _domain = config.GetValue<string>("Domain") ?? string.Empty;
        }

        public SchemaDBModel SchemaDB() => AppSetting.Configuration?.GetSection("SchemaDB")?.Get<SchemaDBModel>() ?? new SchemaDBModel();

        public SqlConnection GetOpenConnection()
        {
            SqlConnection connection = new();
            if (!string.IsNullOrEmpty(_context?.HttpContext?.Request?.Headers["AccessKey"].ToString()))//Check AuthorizeAD or Check AccessKey
            {
                using (var accessToken = LogonDomain().Result)
                {
                    WindowsIdentity.RunImpersonated(accessToken, new Action(() =>
                    {
                        connection = new SqlConnection(this._conStr);
                        connection.Open();
                    }));
                    WindowsIdentity.RunImpersonated(accessToken, () =>
                    {
                        using (connection = new SqlConnection(_conStr))
                        {
                            connection.Open();
                        }
                    });
                }

                return connection;
            }
            else
            {
                connection = new SqlConnection(this._conStr);
                connection.Open();
                return connection;
            }
        }

        public async Task<DataSet> GetOpenConnectionAD()
        {
            var ds = new DataSet();
            var safeAccessTokenHandle = await LogonDomain();
            WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(() =>
            {
                using (SqlConnection _conn = new SqlConnection(_conStr))
                {
                    _conn.Open();
                    SqlDataAdapter sqlData = new SqlDataAdapter("SELECT 1", _conn);
                    sqlData.SelectCommand.CommandType = CommandType.Text;
                    _ = sqlData.Fill(ds);
                }
            }));

            if (ds.Tables.Count < 1 || ds.Tables[0].Rows.Count < 1) throw new InvalidOperationException($"Connect to DB Fail!!!");
            return await Task.FromResult(ds);
        }

        public async Task<SafeAccessTokenHandle> LogonDomain()
        {
            try
            {
                var cText = GetUserInfoFromRedis(_context?.HttpContext?.Request?.Headers["AccessKey"].ToString());
                var userInfo = _cipher.Decrypt(cText).Split("||");
                if (userInfo[0] is null || userInfo[1] is null)
                    throw new InvalidProgramException("Username or Password is invalid(isnull).");

                var userName = userInfo[0];
                var password = userInfo[1];
                bool methodStatus = LogonUser(userName, _domain, password, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, out SafeAccessTokenHandle safeAccessTokenHandle);

                if (!methodStatus)
                    throw new InvalidProgramException($"Username or Password is invalid.");

                return await Task.FromResult(safeAccessTokenHandle);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<(bool success, string message, T data)> Get<T>(string commandText, CommandType type, IEnumerable<SqlParameter>? param = null) where T : new()
        {
            var result = new T();
            try
            {
                _ = CheckIsNullOrWhiteSpace(commandText);
                _conStr = _conStr.Replace(_readwrite, _readonly);
#if DEBUG
                var DS = _GetTest(commandText, type, param);
#else
                var DS = _Get(commandText, type, param);
#endif
                result = DataSetToList<T>(DS);
                return await Task.FromResult((true, "success", result));
            }
            catch (Exception ex)
            {
                return await Task.FromResult((false, ex.Message, result));
            }
        }

        public async Task<(bool success, string message, T1 data, T2 datas)> Gets<T1, T2>(string commandText, CommandType type, IEnumerable<SqlParameter>? param = null) where T1 : new() where T2 : new()
        {
            var result = new T1();
            var results = new T2();

            try
            {
                _ = CheckIsNullOrWhiteSpace(commandText);
                _conStr = _conStr.Replace(_readwrite, _readonly);
#if DEBUG
                var DS = _GetTest(commandText, type, param);
#else
                var DS = _Get(commandText, type, param);
#endif
                var dsResult = DataSetToLists<T1, T2>(DS);
                result = dsResult.Item1;
                results = dsResult.Item2;
                return await Task.FromResult((true, "success", result, results));
            }
            catch (Exception ex)
            {
                return await Task.FromResult((false, ex.Message, result, results));
            }
        }

        public async Task<(bool success, string message, T data)> QueryAsync<T>(string commandText, CommandType commandType, IEnumerable<SqlParameter>? param = null, bool ReadAndWrite = false) where T : new()
        {
            var result = new T();
            try
            {
                if (ReadAndWrite)
                {
                    _conStr = _conStr.Replace(_readonly, _readwrite);
                }
#if DEBUG
                var DS = await QueryByLocal(commandText, commandType, param);
#else
                var DS = await QueryByImpersonated(commandText, commandType, param);
#endif
                result = DataSetToList<T>(DS);
                return await Task.FromResult((true, "success", result));
            }
            catch (Exception ex)
            {
                return await Task.FromResult((false, ex.Message, result));
            }
        }

        public async Task<(bool success, string message, int numberRowsAffected)> ExecuteAsync(string commandText, CommandType commandType, IEnumerable<SqlParameter>? param = null)
        {
            (bool success, string message, int numberRowsAffected) result;
            try
            {
                _conStr = _conStr.Replace(_readonly, _readwrite);
                int numberRowsAffected = 0;
#if DEBUG
                using (var connection = GetOpenConnection())
                {
                    SqlCommand cmd = new SqlCommand(commandText, connection);
                    cmd.CommandType = commandType;
                    if (param != null && param.Any())
                    {
                        cmd.Parameters.AddRange(param.ToArray());
                    }

                    numberRowsAffected = await cmd.ExecuteNonQueryAsync();
                }
#else
                var cText = GetUserInfoFromRedis(_context?.HttpContext?.Request.Headers["AccessKey"].ToString());
                var userInfo = _cipher.Decrypt(cText).Split("||");
                if (userInfo[0] is null || userInfo[1] is null) 
                    throw new InvalidProgramException("Username or Password is invalid(isnull).");

                var userName = userInfo[0];
                var password = userInfo[1];
                bool methodStatus = LogonUser(userName, _domain, password, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, out SafeAccessTokenHandle safeAccessTokenHandle);

                if (!methodStatus)
                    throw new InvalidProgramException($"Username or Password is invalid.");

                WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(async () =>
                {
                    using (var connection = GetOpenConnection())
                    {
                        SqlCommand cmd = new SqlCommand(commandText, connection);
                        cmd.CommandType = commandType;
                        if (param != null && param.Any())
                        {
                            cmd.Parameters.AddRange(param.ToArray());
                        }
                        // Support AS400 DBlink
                           
                        numberRowsAffected = await cmd.ExecuteNonQueryAsync();
                    }
                }));
#endif
                if (numberRowsAffected > 0) result = (true, $"{numberRowsAffected} rows affected.", numberRowsAffected);
                else result = (true, $"The command was executed but {numberRowsAffected} row affected.", numberRowsAffected);
            }
            catch (Exception ex)
            {
                result = (false, ex.Message, 0);
            }
            return await Task.FromResult(result);
        }

        public async Task<(bool success, string message)> Execute(string commandText, CommandType type, IEnumerable<SqlParameter>? param = null)
        {
            (bool success, string message) result;
            try
            {
                _ = CheckIsNullOrWhiteSpace(commandText);
                _conStr = _conStr.Replace(_readonly, _readwrite);
#if DEBUG
                var afrows = await _ExecuteTest(commandText, type, param);
#else
                var afrows = await _Execute(commandText, type, param);
#endif
                if (afrows > 0) result = (true, "success");
                else result = (true, "The command was executed but 0 row affected.");
            }
            catch (Exception ex)
            {
                result = (false, ex.Message);
            }
            return await Task.FromResult(result);
        }

        public DataSet _Get(string commandText, CommandType type, IEnumerable<SqlParameter> param)
        {
            DataSet DS = new DataSet();
            var cText = GetUserInfoFromRedis(_context?.HttpContext?.Request?.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null) throw new InvalidOperationException("Username or Password is invalid(isnull).");

            bool methodStatus = LogonUser(userInfo[0],
                                            _domain,
                                            userInfo[1],
                                            LOGON32_LOGON_INTERACTIVE,
                                            LOGON32_PROVIDER_DEFAULT,
                                            out SafeAccessTokenHandle safeAccessTokenHandle);

            if (methodStatus)
            {
                WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(
                () =>
                {
                    using (SqlConnection _conn = new SqlConnection(_conStr))
                    {
                        _conn.Open();
                        SqlDataAdapter sqlData = new SqlDataAdapter(commandText, _conn);
                        sqlData.SelectCommand.CommandType = type;
                        if (param != null && param.Any())
                        {
                            foreach (var p in param)
                            {
                                sqlData.SelectCommand.Parameters.AddWithValue(p.ParameterName, p.Value);
                            }
                        }
                        sqlData.Fill(DS);
                    }
                }));
            }
            else
            {
                throw new InvalidOperationException($"Username or Password is invalid.");
            }

            if (DS.Tables.Count < 1 || DS.Tables[0].Rows.Count < 1) throw new InvalidOperationException($"Data not found ({userInfo[0]})");

            return DS;
        }

        public DataSet _GetTest(string commandText, CommandType type, IEnumerable<SqlParameter>? param = null) // for test on localhost
        {
            DataSet DS = new DataSet();
            using (SqlConnection _conn = new SqlConnection(_conStr))
            {
                _conn.Open();
                SqlDataAdapter sqlData = new SqlDataAdapter(commandText, _conn);
                sqlData.SelectCommand.CommandType = type;
                if (param != null && param.Any())
                {
                    foreach (var p in param)
                    {
                        sqlData.SelectCommand.Parameters.AddWithValue(p.ParameterName, p.Value);
                    }
                }
                sqlData.Fill(DS);
            }
            if (DS.Tables.Count < 1 || DS.Tables[0].Rows.Count < 1) throw new InvalidOperationException($"Data not found.");

            return DS;
        }
        public async Task<int> _Execute(string commandText, CommandType type, IEnumerable<SqlParameter>? param = null, bool ReadAndWrite = true)
        {
            int afrows = 0;
            var cText = GetUserInfoFromRedis(_context?.HttpContext?.Request?.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null) throw new InvalidOperationException("Username or Password is invalid(isnull).");

            bool methodStatus = LogonUser(userInfo[0],
                                            _domain,
                                            userInfo[1],
                                            LOGON32_LOGON_INTERACTIVE,
                                            LOGON32_PROVIDER_DEFAULT,
                                            out SafeAccessTokenHandle safeAccessTokenHandle);

            if (methodStatus)
            {
                WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(
                () =>
                {
                    using (SqlConnection _conn = new SqlConnection(_conStr))
                    {
                        _conn.Open();
                        try
                        {
                            SqlCommand sqlCmd = new SqlCommand(commandText, _conn);
                            sqlCmd.CommandType = type;
                            if (param != null && param.Any()) param.ToList().ForEach(p => sqlCmd.Parameters.AddWithValue(p.ParameterName, p.Value));
                            afrows = sqlCmd.ExecuteNonQuery();
                        }
                        catch (SqlException)
                        {
                            /**/
                        }

                        _conn.Close();
                    }
                }));
                return await Task.FromResult(afrows);
            }
            else
            {
                throw new InvalidOperationException($"Username or Password is invalid.");
            }
        }

        public async Task<int> _ExecuteTest(string commandText, CommandType type, IEnumerable<SqlParameter>? param = null) // for test on localhost
        {
            int afrows = 0;
            using (SqlConnection _conn = new SqlConnection(_conStr))
            {
                _conn.Open();
                try
                {
                    SqlCommand sqlCmd = new SqlCommand(commandText, _conn);
                    sqlCmd.CommandType = type;
                    if (param != null && param.Any()) param.ToList().ForEach(p => sqlCmd.Parameters.AddWithValue(p.ParameterName, p.Value));
                    afrows = sqlCmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    /**/
                }
                _conn.Close();
            }
            return await Task.FromResult(afrows);
        }

        private string GetUserInfoFromRedis(string? key)
        {
            var cypherText = _redis.GetDatabase().StringGet(key);
            if (!cypherText.HasValue) throw new RedisException("Access key not found on redis.");
            return cypherText;
        }

        private T? DataSetToList<T>(DataSet DS) where T : new()
        {
            var result = new T();
            if (result is IList && result.GetType().IsGenericType)
            {
                result = Extension.ConvertToModel<T>(DS.Tables[0]);
            }
            else
            {
                result = Extension.ConvertToModel<List<T>>(DS.Tables[0]).FirstOrDefault();
            }
            return result;
        }

        private (T1?, T2?) DataSetToLists<T1, T2>(DataSet DS) where T1 : new() where T2 : new()
        {
            var result = new T1();
            var results = new T2();
            DataSet dsNew;

            if (DS.Tables[0].Rows.Count > 0)
            {
                dsNew = new DataSet();
                dsNew.Tables.Add(DS.Tables[0].Copy());
                result = DataSetToList<T1>(dsNew);
            }

            if (DS.Tables[1].Rows.Count > 0)
            {
                dsNew = new DataSet();
                dsNew.Tables.Add(DS.Tables[1].Copy());
                results = DataSetToList<T2>(dsNew);
            }
            return (result, results);
        }

        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool LogonUser(string lpszUsername, string lpszDomain, string lpszPassword, int dwLogonType, int dwLogonProvider, out SafeAccessTokenHandle phToken);

        public async Task<(bool success, string message, T data)> GetItems<T>(string commandText, CommandType type, IEnumerable<SqlParameter>? param = null) where T : new()
        {
            var result = new T();
            try
            {
#if DEBUG
                var DS = await GetItemsByLocal(commandText, type, param);
#else
                var DS = await GetItemsByImpersonated(commandText, type, param);
#endif
                result = DataSetToList<T>(DS);
                return await Task.FromResult((true, "success", result));
            }
            catch (Exception ex)
            {
                return await Task.FromResult((false, ex.Message, result));
            }
        }

        private async Task<DataSet> GetItemsByLocal(string commandText, CommandType type, IEnumerable<SqlParameter>? param = null) // for test on localhost
        {
            DataSet DS = new DataSet();
            using (SqlConnection _conn = new SqlConnection(_conStr))
            {
                _conn.Open();
                SqlDataAdapter sqlData = new SqlDataAdapter(commandText, _conn);
                sqlData.SelectCommand.CommandType = type;
                if (param != null && param.Any())
                {
                    foreach (var p in param)
                    {
                        sqlData.SelectCommand.Parameters.AddWithValue(p.ParameterName, p.Value);
                    }
                }
                sqlData.Fill(DS);
            }
            return await Task.FromResult(DS);
        }

        private async Task<DataSet> GetItemsByImpersonated(string commandText, CommandType type, IEnumerable<SqlParameter>? param = null)
        {
            DataSet DS = new DataSet();
            var cText = GetUserInfoFromRedis(_context?.HttpContext?.Request?.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null)
                throw new InvalidProgramException("Username or Password is invalid(isnull).");

            var userName = userInfo[0];
            var password = userInfo[1];
            bool methodStatus = LogonUser(userName, _domain, password, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, out SafeAccessTokenHandle safeAccessTokenHandle);

            if (!methodStatus)
                throw new InvalidProgramException($"Username or Password is invalid.");

            WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(
                () =>
                {
                    using (SqlConnection _conn = new SqlConnection(_conStr))
                    {
                        _conn.Open();
                        SqlDataAdapter sqlData = new SqlDataAdapter(commandText, _conn);
                        sqlData.SelectCommand.CommandType = type;
                        if (param != null && param.Any())
                        {
                            foreach (var p in param)
                            {
                                sqlData.SelectCommand.Parameters.AddWithValue(p.ParameterName, p.Value);
                            }
                        }
                        sqlData.Fill(DS);
                    }
                }));

            return await Task.FromResult(DS);
        }

        private async Task<DataSet> QueryByLocal(string commandText, CommandType commandType, IEnumerable<SqlParameter>? param = null)
        {
            DataSet DS = new DataSet();
            using (var connection = GetOpenConnection())
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandText, connection);
                adapter.SelectCommand.CommandType = commandType;
                if (param != null && param.Any())
                {
                    adapter.SelectCommand.Parameters.AddRange(param.ToArray());
                }

                adapter.Fill(DS);
            }
            return await Task.FromResult(DS);
        }

        private async Task<DataSet> QueryByImpersonated(string commandText, CommandType commandType, IEnumerable<SqlParameter>? param = null)
        {
            DataSet DS = new DataSet();
            var cText = GetUserInfoFromRedis(_context?.HttpContext?.Request?.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null)
                throw new InvalidProgramException("Username or Password is invalid(isnull).");

            var userName = userInfo[0];
            var password = userInfo[1];
            bool methodStatus = LogonUser(userName, _domain, password, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, out SafeAccessTokenHandle safeAccessTokenHandle);

            if (!methodStatus)
                throw new InvalidProgramException($"Username or Password is invalid.");

            WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(() =>
            {
                using (var connection = GetOpenConnection())
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(commandText, connection);
                    adapter.SelectCommand.CommandType = commandType;
                    if (param != null && param.Any())
                    {
                        adapter.SelectCommand.Parameters.AddRange(param.ToArray());
                    }

                    adapter.Fill(DS);
                }
            }));

            return await Task.FromResult(DS);
        }

        private bool CheckIsNullOrWhiteSpace(string commandText)
        {
            if (string.IsNullOrWhiteSpace(commandText)) throw new ArgumentException($"'{nameof(commandText)}' cannot be null or whitespace.", nameof(commandText));
            return false;
        }

        public object UserLogin()
        {
            var cText = GetUserInfoFromRedis(_context?.HttpContext?.Request.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null)
                throw new InvalidProgramException("Username or Password is invalid(isnull).");
            var dataUserInfo = new { username = userInfo[0], password = userInfo[1] };
            return dataUserInfo;
        }
    }
}


