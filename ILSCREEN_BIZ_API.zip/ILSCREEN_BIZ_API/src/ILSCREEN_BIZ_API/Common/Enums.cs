﻿namespace ILSCREEN_BIZ_API.Common
{
    public enum APIServiceMethod
    {
        GET = 0,
        POST = 1,
        PUT = 2,
        DELETE = 3,
        UPLOAD = 4
    }

    public enum RefType
    {
        REQUEST = 0,
        RESPONSE = 1
    }
}
