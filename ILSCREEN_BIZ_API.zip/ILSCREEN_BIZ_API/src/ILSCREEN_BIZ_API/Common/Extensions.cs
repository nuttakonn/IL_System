﻿using ILSCREEN_BIZ_API.Models;
using Newtonsoft.Json;
using System.Collections;
using System.Data;
using System.Globalization;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;

namespace ILSCREEN_BIZ_API.Common
{
    public static class Extensions
    {
        /// <summary>
        /// Validate response and map data to specific type.
        /// </summary>
        /// <typeparam name="T" description="Return type"> </typeparam>
        /// <param name="serviceResult"></param>
        /// <returns></returns>
        public static async Task<T> CheckResult<T>(this ApiServiceResponseModel<ResponseModel> serviceResult)
        {
            if (!serviceResult.IsSuccessStatusCode && !string.IsNullOrEmpty(serviceResult.ReturnMessage))
            {
                throw new InvalidOperationException(serviceResult.ReturnMessage);
            }

            if (!serviceResult.IsSuccessStatusCode && string.IsNullOrEmpty(serviceResult.ReturnMessage))
            {
                var ResponseMessage = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
                throw new InvalidOperationException(ResponseMessage);
            }

            if (serviceResult.Entity.success == false)
            {
                throw new InvalidOperationException($"Service : {serviceResult.RequestUri} | Message : {serviceResult.Entity.message}");
            }

            return await Task.FromResult(ConvertToModel<T>(serviceResult?.Entity?.data));
        }

        public static T? DataSetToList<T>(DataSet DS) where T : new()
        {
            var result = new T();
            if (result is IList && result.GetType().IsGenericType)
            {
                result = ConvertToModel<T>(DS.Tables[0]);
            }
            else
            {
                result = ConvertToModel<List<T>>(DS.Tables[0]).FirstOrDefault();
            }
            return result;
        }
        public static T ConvertToModel<T>(this object dt)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                FloatFormatHandling = FloatFormatHandling.DefaultValue,
            };
            var strDt = JsonConvert.SerializeObject(dt);
            return JsonConvert.DeserializeObject<T>(strDt, settings);
        }

        public static T? Clone<T>(this T obj)
        {
            if (ReferenceEquals(obj, null))
            {
                return default;
            }
            var strobj = JsonConvert.SerializeObject(obj);
            return JsonConvert.DeserializeObject<T>(strobj);
        }
        public static List<T>? Clones<T>(this List<T> obj)
        {
            if (ReferenceEquals(obj, null))
            {
                return default;
            }
            var strobj = JsonConvert.SerializeObject(obj);
            return JsonConvert.DeserializeObject<List<T>>(strobj);
        }

        public static byte[] GetFileArray(this IFormFile file)
        {
            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                return ms.ToArray();
            }
        }
        public static string PBKDF2Encrypt(this string text, string key = "ESB")
        {
            byte[] salt1 = new byte[8];
            using (RNGCryptoServiceProvider rngCsp = new RNGCryptoServiceProvider())
            {
                rngCsp.GetBytes(salt1);
            }

            int myIterations = 1000;
            Rfc2898DeriveBytes k1 = new Rfc2898DeriveBytes(key, salt1, myIterations);

            TripleDES encAlg = TripleDES.Create();
            encAlg.Key = k1.GetBytes(16);

            var encryptionStream = new MemoryStream();
            CryptoStream encrypt = new CryptoStream(encryptionStream, encAlg.CreateEncryptor(), CryptoStreamMode.Write);

            byte[] utfD1 = Encoding.UTF8.GetBytes(text);

            encrypt.Write(utfD1, 0, utfD1.Length);
            encrypt.FlushFinalBlock();
            encrypt.Close();

            byte[] edata1 = encryptionStream.ToArray();
            k1.Reset();

            return $"{System.Convert.ToBase64String(salt1)}|{System.Convert.ToBase64String(encAlg.IV)}|{System.Convert.ToBase64String(edata1)}";
        }
        public static DataSet ConvertXElementToDataset(ArrayOfXElement xElementData, ref string errMsg)
        {
            DataSet ds = new DataSet();
            try
            {
                if (xElementData.Nodes[1].FirstNode != null)
                {
                    ds.ReadXml(new StringReader(xElementData.Nodes[1].FirstNode.ToString()));
                }
            }
            catch (Exception ex)
            {
                errMsg = ex.Message.ToString();
            }
            return ds;
        }

        

        public static List<T> CheckResultHisun<T>(this ILSCREEN_BIZ_API.Models.ApiServiceResponseModel<ILSCREEN_BIZ_API.Models.Common.ServiceaReponseModel<T>> serviceResult)
        {
            if (!serviceResult.IsSuccessStatusCode) throw new ArgumentException(serviceResult.ReturnMessage);
            if (serviceResult.Entity.ReturnCode != 0) throw new ArgumentException($"Service : {serviceResult.RequestUri} | Message : {serviceResult.ReturnMessage}");
            return serviceResult.Entity?.Ds;
        }
        public static string Base64Decode(this string value)
        {
            try
            {
                var base64EncodedBytes = Convert.FromBase64String(value);
                return Encoding.UTF8.GetString(base64EncodedBytes);
            }
            catch (Exception)
            {
                // ignored
            }
            return value;
        }
        public partial class ArrayOfXElement : object, System.Xml.Serialization.IXmlSerializable
        {

            private System.Collections.Generic.List<System.Xml.Linq.XElement> nodesList = new System.Collections.Generic.List<System.Xml.Linq.XElement>();

            public ArrayOfXElement()
            {
            }

            public virtual System.Collections.Generic.List<System.Xml.Linq.XElement> Nodes
            {
                get
                {
                    return this.nodesList;
                }
            }

            public virtual System.Xml.Schema.XmlSchema GetSchema()
            {
                throw new System.NotImplementedException();
            }

            public virtual void WriteXml(System.Xml.XmlWriter writer)
            {
                System.Collections.Generic.IEnumerator<System.Xml.Linq.XElement> e = nodesList.GetEnumerator();
                for (
                ; e.MoveNext();
                )
                {
                    ((System.Xml.Serialization.IXmlSerializable)(e.Current)).WriteXml(writer);
                }
            }

            public virtual void ReadXml(System.Xml.XmlReader reader)
            {
                for (
                ; (reader.NodeType != System.Xml.XmlNodeType.EndElement);
                )
                {
                    if ((reader.NodeType == System.Xml.XmlNodeType.Element))
                    {
                        System.Xml.Linq.XElement elem = new System.Xml.Linq.XElement("default");
                        ((System.Xml.Serialization.IXmlSerializable)(elem)).ReadXml(reader);
                        Nodes.Add(elem);
                    }
                    else
                    {
                        reader.Skip();
                    }
                }
            }
        }

    }

    public static class SystemExtension
    {
        public static bool CompareValuePropertiesModel<T>(T self, T to, params string[] ignore) where T : class
        {
            if (self != null && to != null)
            {
                Type type = typeof(T);
                List<string> ignoreList = new List<string>(ignore);
                foreach (System.Reflection.PropertyInfo pi in type.GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance))
                {
                    if (!ignoreList.Contains(pi.Name))
                    {
                        object selfValue = type.GetProperty(pi.Name).GetValue(self, null);
                        object toValue = type.GetProperty(pi.Name).GetValue(to, null);

                        if (selfValue != toValue && (selfValue == null || !selfValue.Equals(toValue)))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            return self == to;
        }

        public static bool IsAnyNullOrEmpty(this object myObject)
        {
            #region This Short Code: IsAnyNullOrEmpty
            //bool checkValueNotNull = myObject.GetType().GetProperties()
            //    .Where(pi => pi.PropertyType == typeof(string))
            //    .Select(pi => (string)pi.GetValue(myObject))
            //    .Any(value => string.IsNullOrEmpty(value) || value == "string");
            //return checkValueNotNull;
            #endregion This Short Code: IsAnyNullOrEmpty

            foreach (PropertyInfo pi in myObject.GetType().GetProperties())
            {
                if (pi.PropertyType == typeof(string))
                {
                    string value = (string)pi.GetValue(myObject);
                    if (string.IsNullOrEmpty(value) || value == "string")
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    public static class DateTimeExtension
    {
        private static bool isBuddhistFormat = $"th".Equals(CultureInfo.CurrentCulture.ToString().Substring(0, 2));
        public static string ToBuddhistDateString(this DateTime date, string dateFormat = "yyyyMMdd")
        {
            if (isBuddhistFormat)
            {
                return date.ToString(dateFormat);
            }

            Thread.CurrentThread.CurrentCulture = new CultureInfo("th-TH");
            string result = date.ToString(dateFormat);
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            return result;
        }

        public static string ToUniversalDateString(this DateTime date, string dateFormat = "yyyyMMdd")
        {
            if (isBuddhistFormat)
            {
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
                string result = date.ToString(dateFormat);
                Thread.CurrentThread.CurrentCulture = new CultureInfo("th-TH");
                return result;
            }

            return date.ToString(dateFormat);
        }

        public static string ToBuddhistDateTimeStringFormat(this DateTime? dateTime, string format = "dd/MM/yyyy HH:mm:ss")
        {
            if (dateTime == null)
                return null;

            if (!dateTime.HasValue)
                return string.Empty;

            if (isBuddhistFormat)
                return dateTime.Value.ToString(format);


            Thread.CurrentThread.CurrentCulture = new CultureInfo("th-TH");
            string result = dateTime.Value.ToString(format);
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            return result;
        }

        public static string ToUniversalDateTimeStringFormat(this DateTime? dateTime, string format = "dd/MM/yyyy HH:mm:ss")
        {
            if (dateTime == null)
                return null;

            if (!dateTime.HasValue)
                return string.Empty;

            if (!isBuddhistFormat)
                return dateTime.Value.ToString(format);


            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            string result = dateTime.Value.ToString(format);
            Thread.CurrentThread.CurrentCulture = new CultureInfo("th-TH");
            return result;
        }

        static public string ToBuddhistDateTimeString(this DateTime date, string dateFormat = "yyyyMMdd", string timeFormat = "HH:mm:ss")
        {
            try
            {
                if (string.IsNullOrWhiteSpace(timeFormat))
                {
                    return date.ToBuddhistDateString(dateFormat);
                }
                else
                {
                    return date.ToString($"{dateFormat} {timeFormat}", CultureInfo.CreateSpecificCulture("th-TH"));
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Cannot Convert DateTime to Buddhist DateTime String {ex} {date.ToString()}");
            }
        }

        static public string ToUniversalDateTimeString(this DateTime date, string dateFormat = "yyyyMMdd", string timeFormat = "HH:mm:ss")
        {
            try
            {
                if (string.IsNullOrWhiteSpace(timeFormat))
                {
                    return date.ToUniversalDateString(dateFormat);
                }
                else
                {
                    return date.ToString($"{dateFormat} {timeFormat}", CultureInfo.CreateSpecificCulture("en-US"));
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Cannot Convert DateTime to Universal DateTime String {ex} {date.ToString()}");
            }
        }

        static public DateTime ToBuddhistDateTime(this DateTime date)
        {
            try
            {
                return date.AddYears(543);
            }
            catch (Exception ex)
            {
                throw new Exception($"Cannot Convert DateTime to Buddhist DateTime {ex} {date.ToString()}");
            }
        }

        static public DateTime ToUniversalDateTime(this DateTime date)
        {
            try
            {
                return date.AddYears(-543);
            }
            catch (Exception ex)
            {
                throw new Exception($"Cannot Convert DateTime to Universal DateTime {ex} {date.ToString()}");
            }
        }
    }

    public static class EntitesExtension
    {
        static public bool IsEmpty<T>(this IEnumerable<T> obj)
        {
            if (obj?.Any() != true)
            {
                return true;
            }
            return false;
        }
    }

}
