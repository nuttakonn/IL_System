﻿using ILSCREEN_BIZ_API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Numerics;

namespace ILSCREEN_BIZ_API.Controllers
{
    [Produces("application/json")]
    [ApiController]
    [Route("api/[controller]")]
    public class ProcessController : Controller
    {
        private readonly IProcessService _processService;
        public ProcessController(IProcessService processService)
        {
            _processService = processService;
        }

        [HttpGet]
        [Route("GetMonitorCaseUnsign")]
        public async Task<IActionResult> GetMonitorCaseUnsign(string vendor)
        {
            try
            {
                var result = await _processService.GetMonitorCaseUnsign(vendor);
                if (result.success)
                {
                    if (result.data == null) 
                        return NotFound(new { success = true, message = "Data not found." });

                    return Ok(result);
                }
                else
                {
                    return StatusCode(500, result);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "An error occurred.", detail = ex.Message });
            }
        }
        [HttpGet]
        [Route("GetVendorListMonitorCaseUnsign")]
        public async Task<IActionResult> GetVendorListMonitorCaseUnsign()
        {
            try
            {
                var result = await _processService.GetVendorListMonitorCaseUnsign();
                if (result.success)
                {
                    if (result.data == null)
                        return NotFound(new { success = true, message = "Data not found." });

                    return Ok(result);
                }
                else
                {
                    return StatusCode(500, result);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "An error occurred.", detail = ex.Message });
            }
        }
        [HttpPost]
        [Route("CalculateInstallmentMonitorCaseUnsign")]
        public async Task<IActionResult> CalculateInstallmentMonitorCaseUnsign(string contract, string appno) 
        {
            try
            {
                var result = await _processService.CalculateInstallmentMonitorCaseUnsign(contract, appno);
                if (result.success)
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode(500, result);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "An error occurred.", detail = ex.Message });
            }
        }
    }
}
