﻿using ILSCREEN_BIZ_API.Models;
using ILSCREEN_BIZ_API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Buffers;

namespace ILSCREEN_BIZ_API.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : Controller
    {
        private readonly IAccountService _acSV;
        public AccountController(IAccountService acSV)
        {
            _acSV = acSV;
        }

        [HttpGet("GetViewVendorMaster")]
        public async Task<IActionResult> GetViewVendorMaster(string searchBy, string searchValue)
        {
            ResponseModel returnResponse = new ResponseModel();
            try
            {
                returnResponse = await _acSV.GetViewVendorMaster(searchBy, searchValue);
                return Ok(returnResponse);
            }
            catch (Exception ex)
            {
                returnResponse.message = $"{ex.Message} - {ex.InnerException}";
                return BadRequest(returnResponse);
            }
        }
    }
}
