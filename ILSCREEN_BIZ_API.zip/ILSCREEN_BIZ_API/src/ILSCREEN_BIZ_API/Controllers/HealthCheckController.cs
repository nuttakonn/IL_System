﻿using ILSCREEN_BIZ_API.Models;
using ILSCREEN_BIZ_API.Models.Common;
using ILSCREEN_BIZ_API.Services.Common;
using Microsoft.AspNetCore.Mvc;

namespace ILSCREEN_BIZ_API.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class HealthCheckController : ControllerBase
    {
        private readonly CheckService _apiChecking;
        private List<MicroServicesModel>? ListAPI = new List<MicroServicesModel>();
        public HealthCheckController(CheckService apiChecking)
        {
            _apiChecking = apiChecking;
        }

        [HttpGet(Name = "APIHealthCheck")]
        public object APIHealthCheck()
        {
            return Ok(new { status = 200, success = true, message = $"Connect {AppSetting.AssemblyName} Success!" });
        }

        [HttpGet("ServiceCheck", Name = "ServiceCheck")]
        public async Task<IActionResult> ServiceCheck()
        {
            try
            {
                var result = await CallApiService(false);
                return await Task.FromResult(Ok(new { status = 200, success = true, data = result }));
            }
            catch (Exception ex)
            {
                return await Task.FromResult(BadRequest($"{ex.Message} | Inner: {ex.InnerException?.Message}"));
            }
        }

        private async Task<List<CheckServiceModel>> CallApiService(bool isRefresh)
        {
            if (isRefresh)
            {
                ListAPI?.Clear();
            }

            ListAPI = AppSetting.MicroServices();
            var tasks = new List<CheckServiceModel>();
            foreach (var api in ListAPI ?? new List<MicroServicesModel>())
            {
                var task = await _apiChecking.CallHealthCheckAsync(api);
                tasks.Add(new CheckServiceModel { Host = task.Item2, ServiceName = task.Item3, IP = task.Item4, Version = task.Item5, Status = task.Item1.status, Remarks = $"{task.Item1.message}" });
            }
            //var redis = await _apiChecking.CheckConnectionRedis();
            //tasks.Add(redis);
            //var logRDS = await _apiChecking.CheckConnectionLog();
            //tasks.Add(logRDS);

            return tasks;
        }
    }
}
