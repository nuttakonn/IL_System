﻿using ILSCREEN_BIZ_API.Models;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;
using System.Net;
using System.Reflection;

namespace ILSCREEN_BIZ_API.API
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var assemblyAll = Assembly.GetEntryAssembly()?.GetName();
            IndexModel model = new IndexModel();
            model.IP = GetIPAddress();
            model.AssemblyName = assemblyAll?.Name;
            model.AssemblyVersion = assemblyAll?.Version?.ToString();
            model.AspNetCoreEnvironment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            model.DateModified = GetDateModified();
            return View(model);
        }

        private string GetIPAddress()
        {
            try
            {
                IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
                return Dns.GetHostEntry(Dns.GetHostName()).HostName;
            }
            catch
            {
                return "";
            }
        }

        private string GetDateModified()
        {
            var assemblyExe = Assembly.GetExecutingAssembly();
            FileInfo file = new FileInfo(assemblyExe.Location);
            return file.LastWriteTime.ToString("dd/MM/yyyy - HH:mm:ss", new CultureInfo("en-EN", false));
        }
    }
}
