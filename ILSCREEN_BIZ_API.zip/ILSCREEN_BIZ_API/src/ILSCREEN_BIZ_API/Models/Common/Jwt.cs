﻿namespace ILSCREEN_BIZ_API.Models
{
    public class Jwt
    {
        public string? Key { get; set; }
        public string? Issuer { get; set; }
        public string? IssuerNote { get; set; }
        public string? IssuerBusiness { get; set; }
        public string? IssuerCustomer { get; set; }
        public string? IssuerReceiveWithdraw { get; set; }
        public string? IssuerServicea { get; set; }
        public string? ExpireMinutes { get; set; }
        public string? Role { get; set; }
        public string? Username { get; set; }
        public string? Password { get; set; }
        public bool Enable { get; set; }
        public bool Authen { get; set; }
        public string? ActionIgnore { get; set; }
    }
}
