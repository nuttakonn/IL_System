﻿namespace ILSCREEN_BIZ_API.Models.Common
{
    public class MicroServicesModel
    {
        public string? name { get; set; }
        public string? host { get; set; }
    }
}
