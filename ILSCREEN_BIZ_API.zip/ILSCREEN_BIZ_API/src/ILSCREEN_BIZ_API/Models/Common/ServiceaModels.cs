﻿using System.Text.Json.Serialization;
using System.Collections.Generic;

namespace ILSCREEN_BIZ_API.Models.Common
{
    public class ServiceaRequestModel
    {
        [JsonPropertyName("TIA")]
        public List<string> TIA { get; set; }

        [JsonPropertyName("PROGRAM")]
        public string PROGRAM { get; set; }

        [JsonPropertyName("AppName")]
        public string AppName { get; set; }
    }

    public class ServiceaResponseModel<T>
    {
        [JsonPropertyName("ReturnCode")]
        public int ReturnCode { get; set; }
        [JsonPropertyName("TOA")]
        public List<string> TOA { get; set; }
        [JsonPropertyName("DS")]
        public List<T> Ds { get; set; }
    }


}
