﻿namespace ILSCREEN_BIZ_API.Models
{
    public class RequestTokenModel
    {
        public string? userName { set; get; } = "";
        public string? password { set; get; } = "";
        public string? role { set; get; } = "";
        public string? issuer { set; get; } = "";
        public int expiresMinutes { set; get; } = 3;
    }

    public class ResultTokenModel
    {
        public string? token { get; set; }
    }
}
