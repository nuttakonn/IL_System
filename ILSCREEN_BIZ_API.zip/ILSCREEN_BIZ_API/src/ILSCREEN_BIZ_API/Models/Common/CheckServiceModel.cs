﻿namespace ILSCREEN_BIZ_API.Models
{
    public class CheckServiceModel
    {
        public string? ServiceName { get; set; }
        public string? Host { get; set; }
        public int Status { get; set; }
        public string? Remarks { get; set; }
        public string? IP { get; set; }
        public string? Version { get; set; }
    }
}
