﻿using ILSCREEN_BIZ_API.Models;

namespace ILSCREEN_BIZ_API.Services.Interfaces
{
    public interface IAccountService
    {
        Task<ResponseModel> GetViewVendorMaster(string searchBy, string searchValue);

    }
}