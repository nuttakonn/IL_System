﻿using ILSCREEN_BIZ_API.Models;

namespace ILSCREEN_BIZ_API.Services.Interfaces
{
    public interface IProcessService
    {
        public Task<ResponseModel> GetMonitorCaseUnsign(string vendor);
        public Task<ResponseModel> GetVendorListMonitorCaseUnsign();
        public Task<ResponseModel> CalculateInstallmentMonitorCaseUnsign(string contract, string appno);

    }
}