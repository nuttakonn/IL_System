﻿using ILSCREEN_BIZ_API.Common;
using ILSCREEN_BIZ_API.Models;
using ILSCREEN_BIZ_API.Services.Common;
using ILSCREEN_BIZ_API.Services.Log;
using ILSCREEN_BIZ_API.Services.MicroServices.Interface;
using Newtonsoft.Json;

namespace ILSCREEN_BIZ_API.Services.MicroServices
{
    public class AccountingMicroService : IAccountingMicroService
    {
        protected readonly Jwt _jwtConfig;
        protected readonly LogBusinessService _logService;
        protected readonly IHttpContextAccessor _httpContextAccessor;
        protected readonly ITokenMicroService _tokenService;

        public AccountingMicroService(ITokenMicroService tokenService, IHttpContextAccessor httpContextAccessor, LogBusinessService logService)
        {
            _logService = logService;
            _tokenService = tokenService;
            _httpContextAccessor = httpContextAccessor;
            _jwtConfig = AppSetting.Configuration?.GetSection("Jwt")?.Get<Jwt>() ?? new Jwt();
        }

        private string GetMicroServiceHost()
        {
            return AppSetting.MicroService("ACCOUNTING_API") ?? "";
        }

        private async Task<ApiServiceResponseModel<T>> Send<T>(string url, object parameter, APIServiceMethod method)
        {
            ApiServiceResponseModel<T> serviceResult = new ApiServiceResponseModel<T>();
            string correlationId = _httpContextAccessor.HttpContext?.Request.Headers["_CorrelationId_"].ToString() ?? "";
            string authenInfo = _httpContextAccessor.HttpContext?.Request.Headers["AccessKey"].ToString() ?? "";

            string refId = Guid.NewGuid().ToString();
            if (_jwtConfig.Authen)
            {
                bool useTokenJwt = _jwtConfig.Authen;
                var serviceTokenResult = await _tokenService.GenerateNewToken<ResponseModel>(correlationId, _jwtConfig.IssuerBusiness);
                if (!serviceTokenResult.IsSuccessStatusCode) { throw new Exception(serviceResult.ReturnMessage); }
                if (!serviceTokenResult.Entity.success) { throw new Exception($"Service : {serviceResult.RequestUri}"); }

                var resultToken = serviceTokenResult.Entity?.data?.ConvertToModel<ResultTokenModel>();

                string accessToken = !string.IsNullOrEmpty(resultToken?.token) ? $"Bearer {resultToken.token}" : "";
                ApiService apiService = new ApiService(GetMicroServiceHost(), url, parameter, useTokenJwt, accessToken, method, authenInfo);

                // Log Request
                string requestUrl = new Uri(new Uri(apiService.BaseAddress), apiService.RequestUri).AbsoluteUri;
                string requestBody = JsonConvert.SerializeObject(parameter);
                string requestMethod = method.ToString();

                //_ = Task.Run(() => _logService.InsertLogRequest(correlationId, refId, requestMethod, requestUrl, requestBody, "BIZ"));
                new Thread(() => _ = _logService.InsertLogRequest(correlationId, refId, requestMethod, requestUrl, requestBody, "BIZ")).Start();

                // Call MicroService
                serviceResult = await apiService.CallMicroService<T>();

                // Log Response
                int responseStatusCode = (int)serviceResult.StatusCode;
                string responseMessage = "";

                if (!serviceResult.IsSuccessStatusCode)
                {
                    responseMessage = $"Service:{serviceResult.RequestUri} | Message:[{(int)serviceResult.StatusCode} {serviceResult.StatusCode}] : {serviceResult.ReturnMessage}";
                }
                else
                {
                    responseMessage = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
                }

                //_ = Task.Run(() => _logService.InsertLogResponse(correlationId, refId, responseStatusCode, responseMessage, "BIZ"));
                new Thread(() => _ = _logService.InsertLogResponse(correlationId, refId, responseStatusCode, responseMessage, "BIZ")).Start();
            }
            else
            {
                ApiService apiService = new ApiService(GetMicroServiceHost(), url, parameter, false, null, method, authenInfo);

                // Log Request
                string requestUrl = new Uri(new Uri(apiService.BaseAddress), apiService.RequestUri).AbsoluteUri;
                string requestBody = JsonConvert.SerializeObject(parameter);
                string requestMethod = method.ToString();

                //_ = Task.Run(() => _logService.InsertLogRequest(correlationId, refId, requestMethod, requestUrl, requestBody, "BIZ"));
                new Thread(() => _ = _logService.InsertLogRequest(correlationId, refId, requestMethod, requestUrl, requestBody, "BIZ")).Start();

                // Call MicroService
                serviceResult = await apiService.CallMicroService<T>();

                // Log Response
                int responseStatusCode = (int)serviceResult.StatusCode;
                string responseMessage = "";

                if (!serviceResult.IsSuccessStatusCode)
                {
                    responseMessage = $"Service:{serviceResult.RequestUri} | Message:[{(int)serviceResult.StatusCode} {serviceResult.StatusCode.ToString()}] : {serviceResult.ReturnMessage}";
                }
                else
                {
                    responseMessage = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
                }

                //_ = Task.Run(() => _logService.InsertLogResponse(correlationId, refId, responseStatusCode, responseMessage, "BIZ"));
                new Thread(() => _ = _logService.InsertLogResponse(correlationId, refId, responseStatusCode, responseMessage, "BIZ")).Start();
            }

            return serviceResult;
        }

        public async Task<ApiServiceResponseModel<T>> GetWithdrawDetail<T>(string contractId)
        {
            string url = $"/api/WithdrawInfo/GetContractWithdrawRL/" + contractId;
            return await Send<T>(url, null, APIServiceMethod.GET);
        }
    }
}
