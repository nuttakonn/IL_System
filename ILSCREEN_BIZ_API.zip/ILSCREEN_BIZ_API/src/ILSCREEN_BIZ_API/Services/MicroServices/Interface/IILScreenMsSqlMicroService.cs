﻿using ILSCREEN_BIZ_API.Models;

namespace ILSCREEN_BIZ_API.Services.MicroServices.Interface
{
    public interface IILScreenMsSqlMicroService
    {
        public Task<ApiServiceResponseModel<T>> GetMonitorCaseUnsign<T>(string vendor);
        public Task<ApiServiceResponseModel<T>> GetVendorListMonitorCaseUnsign<T>();
        public Task<ApiServiceResponseModel<T>> GetViewVendorMaster<T>(string searchBy, string searchValue);

    }
}