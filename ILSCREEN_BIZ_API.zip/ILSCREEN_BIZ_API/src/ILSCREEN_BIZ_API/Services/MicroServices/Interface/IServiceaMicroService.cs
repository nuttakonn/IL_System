﻿using ILSCREEN_BIZ_API.Models;
using ILSCREEN_BIZ_API.Models.Common;

namespace ILSCREEN_BIZ_API.Services.MicroServices.Interface
{
    public interface IServiceaMicroService
    {
        public Task<ApiServiceResponseModel<T>> CallServiceA<T>(ServiceaRequestModel request);
        public Task<ServiceaResponseModel<T>> CheckResultHisun<T>(ApiServiceResponseModel<T> serviceResult);

    }
}
