﻿using ILSCREEN_BIZ_API.Models;

namespace ILSCREEN_BIZ_API.Services.MicroServices.Interface
{
    public interface IAccountingMicroService
    {
        public Task<ApiServiceResponseModel<T>> GetWithdrawDetail<T>(string contractId);
    }
}
