﻿using ILSCREEN_BIZ_API.Models;

namespace ILSCREEN_BIZ_API.Services.MicroServices.Interface
{
    public interface ITokenMicroService
    {
        Task<ApiServiceResponseModel<T>> GenerateNewToken<T>(string correlationId, string issuer);
    }
}
