﻿using ILSCREEN_BIZ_API.Common;
using ILSCREEN_BIZ_API.Models;
using ILSCREEN_BIZ_API.Services.Common;
using ILSCREEN_BIZ_API.Services.Log;
using ILSCREEN_BIZ_API.Services.MicroServices.Interface;
using Newtonsoft.Json;

namespace ILSCREEN_BIZ_API.Services.MicroServices
{
    public class TokenMicroService : ITokenMicroService
    {
        protected readonly Jwt _jwtConfig;
        protected readonly LogBusinessService _logService;
        public TokenMicroService(LogBusinessService logService)
        {
            _logService = logService;
            _jwtConfig = AppSetting.Configuration?.GetSection("Jwt")?.Get<Jwt>() ?? new Jwt();
        }

        private string GetMicroServiceHost()
        {
            return AppSetting.MicroService("TOKEN_API")?.ToString() ?? "";
        }

        public async Task<ApiServiceResponseModel<T>> GenerateNewToken<T>(string correlationId, string issuer)
        {
            string refId = Guid.NewGuid().ToString();
            string url = "/api/Token/BuildToken";
            var requestToken = new RequestTokenModel { userName = _jwtConfig.Username, password = _jwtConfig.Password, issuer = issuer, expiresMinutes = int.Parse(_jwtConfig.ExpireMinutes ?? "3"), role = _jwtConfig.Role };
            ApiService apiService = new ApiService(GetMicroServiceHost(), url, requestToken, false, string.Empty, APIServiceMethod.POST, "");
            // Log Request
            string requestUrl = new Uri(new Uri(apiService.BaseAddress), apiService.RequestUri).AbsoluteUri;
            string requestBody = JsonConvert.SerializeObject(requestToken);
            string requestMethod = APIServiceMethod.POST.ToString();

            //_ = Task.Run(() => _logService.InsertLogRequest(correlationId, refId, requestMethod, requestUrl, requestBody, "BIZ"));
            new Thread(() => _ = _logService.InsertLogRequest(correlationId, refId, requestMethod, requestUrl, requestBody, "BIZ")).Start();

            // Call MicroService
            ApiServiceResponseModel<T> serviceResult = await apiService.CallMicroService<T>();

            // Log Response
            int responseStatusCode = (int)serviceResult.StatusCode;
            string responseMessage = ""; // !serviceResult.IsSuccessStatusCode ? serviceResult.ReturnMessage : await serviceResult.ResponseMessage.Content.ReadAsStringAsync();

            /* remove more error for ui */
            if (!serviceResult.IsSuccessStatusCode)
            {
                responseMessage = $"Service:{serviceResult.RequestUri} | Message:[{(int)serviceResult.StatusCode} {serviceResult.StatusCode.ToString()}] : {serviceResult.ReturnMessage}";
            }
            else
            {
                responseMessage = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
            }

            //_ = Task.Run(() => _logService.InsertLogResponse(correlationId, refId, responseStatusCode, responseMessage, "BIZ"));
            new Thread(() => _ = _logService.InsertLogResponse(correlationId, refId, responseStatusCode, responseMessage, "BIZ")).Start();

            return serviceResult;
        }
    }
}
