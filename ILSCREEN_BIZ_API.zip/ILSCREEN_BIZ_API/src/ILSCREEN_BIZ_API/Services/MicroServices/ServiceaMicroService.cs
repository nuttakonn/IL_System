﻿using ILSCREEN_BIZ_API.Common;
using ILSCREEN_BIZ_API.Models;
using ILSCREEN_BIZ_API.Models.Common;
using ILSCREEN_BIZ_API.Services.Common;
using ILSCREEN_BIZ_API.Services.Log;
using ILSCREEN_BIZ_API.Services.MicroServices.Interface;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections;
using System.Net;
using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

namespace ILSCREEN_BIZ_API.Services.MicroServices
{
    public class ServiceaMicroService : IServiceaMicroService
    {
        protected readonly Jwt _jwtConfig;
        protected readonly LogBusinessService _logService;
        protected readonly IHttpContextAccessor _httpContextAccessor;
        protected readonly ITokenMicroService _tokenService;

        public ServiceaMicroService(ITokenMicroService tokenService, IHttpContextAccessor httpContextAccessor, LogBusinessService logService)
        {
            _logService = logService;
            _tokenService = tokenService;
            _httpContextAccessor = httpContextAccessor;
            _jwtConfig = AppSetting.Configuration?.GetSection("Jwt")?.Get<Jwt>() ?? new Jwt();
        }

        private string GetMicroServiceHost()
        {
            return AppSetting.MicroService("SERVICE_A") ?? "";
        }

        private async Task<ApiServiceResponseModel<T>> Send<T>(string url, object parameter, APIServiceMethod method)
        {
            ApiServiceResponseModel<T> serviceResult = new ApiServiceResponseModel<T>();
            string correlationId = _httpContextAccessor.HttpContext?.Request.Headers["_CorrelationId_"].ToString() ?? "";
            string authenInfo = _httpContextAccessor.HttpContext?.Request.Headers["AccessKey"].ToString() ?? "";

            string refId = Guid.NewGuid().ToString();
            if (_jwtConfig.Authen)
            {
                bool useTokenJwt = _jwtConfig.Authen;
                var serviceTokenResult = await _tokenService.GenerateNewToken<ResponseModel>(correlationId, _jwtConfig.Issuer);
                if (!serviceTokenResult.IsSuccessStatusCode) { throw new Exception(serviceResult.ReturnMessage); }
                if (!serviceTokenResult.Entity.success) { throw new Exception($"Service : {serviceResult.RequestUri}"); }

                var resultToken = serviceTokenResult.Entity?.data?.ConvertToModel<ResultTokenModel>();

                string accessToken = !string.IsNullOrEmpty(resultToken?.token) ? $"Bearer {resultToken.token}" : "";
                ApiService apiService = new ApiService(GetMicroServiceHost(), url, parameter, useTokenJwt, accessToken, method, authenInfo);

                // Log Request
                string requestUrl = new Uri(new Uri(apiService.BaseAddress), apiService.RequestUri).AbsoluteUri;
                string requestBody = JsonConvert.SerializeObject(parameter);
                string requestMethod = method.ToString();

                new Thread(() => _ = _logService.InsertLogRequest(correlationId, refId, requestMethod, requestUrl, requestBody, "BIZ")).Start();

                // Call MicroService
                serviceResult = await apiService.CallMicroService<T>();

                // Log Response
                int responseStatusCode = (int)serviceResult.StatusCode;
                string responseMessage = "";

                if (!serviceResult.IsSuccessStatusCode)
                {
                    responseMessage = $"Service:{serviceResult.RequestUri} | Message:[{(int)serviceResult.StatusCode} {serviceResult.StatusCode}] : {serviceResult.ReturnMessage}";
                }
                else
                {
                    responseMessage = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
                }

                new Thread(() => _ = _logService.InsertLogResponse(correlationId, refId, responseStatusCode, responseMessage, "BIZ")).Start();
            }
            else
            {
                ApiService apiService = new ApiService(GetMicroServiceHost(), url, parameter, false, null, method, authenInfo);

                // Log Request
                string requestUrl = new Uri(new Uri(apiService.BaseAddress), apiService.RequestUri).AbsoluteUri;
                string requestBody = JsonConvert.SerializeObject(parameter);
                string requestMethod = method.ToString();

                new Thread(() => _ = _logService.InsertLogRequest(correlationId, refId, requestMethod, requestUrl, requestBody, "BIZ")).Start();

                // Call MicroService
                serviceResult = await apiService.CallMicroService<T>();

                // Log Response
                int responseStatusCode = (int)serviceResult.StatusCode;
                string responseMessage = "";

                if (!serviceResult.IsSuccessStatusCode)
                {
                    responseMessage = $"Service:{serviceResult.RequestUri} | Message:[{(int)serviceResult.StatusCode} {serviceResult.StatusCode.ToString()}] : {serviceResult.ReturnMessage}";
                }
                else
                {
                    responseMessage = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
                }

                new Thread(() => _ = _logService.InsertLogResponse(correlationId, refId, responseStatusCode, responseMessage, "BIZ")).Start();
            }

            return serviceResult;
        }
        private async Task<ApiServiceResponseModel<T>> SendToServicea<T>(string url, ServiceaRequestModel request, APIServiceMethod method)
        {
            ApiServiceResponseModel<T> serviceResult = new ApiServiceResponseModel<T>();
            string correlationId = _httpContextAccessor.HttpContext?.Request.Headers["_CorrelationId_"].ToString() ?? "";
            string authenInfo = _httpContextAccessor.HttpContext?.Request.Headers["AccessKey"].ToString() ?? "";
            string accessToken = _httpContextAccessor.HttpContext?.Request.Headers["Authorization"].ToString() ?? "";
            string refId = Guid.NewGuid().ToString();

            if (_jwtConfig.Authen)
            {
                bool useTokenJwt = _jwtConfig.Authen;
                var serviceTokenResult = await _tokenService.GenerateNewToken<ResponseModel>(correlationId, _jwtConfig.IssuerServicea);
                if (!serviceTokenResult.IsSuccessStatusCode) { throw new ArgumentNullException(serviceResult.ReturnMessage); }
                if (!serviceTokenResult.Entity.success) { throw new ArgumentNullException($"Service : {serviceResult.RequestUri}"); }
                var resultToken = serviceTokenResult.Entity?.data?.ConvertToModel<ResultTokenModel>();
                accessToken = !string.IsNullOrEmpty(resultToken?.token) ? $"Bearer {resultToken.token}" : "";
                ApiService apiService = new ApiService(GetMicroServiceHost(), url, request, useTokenJwt, accessToken, method, authenInfo);
                apiService.AccessKey = authenInfo;


                // Log Request
                string requestUrl = new Uri(new Uri(apiService.BaseAddress), apiService.RequestUri).AbsoluteUri;
                string requestBody = JsonConvert.SerializeObject(request);
                string requestMethod = method.ToString();
                new Thread(() => _ = _logService.InsertLogRequest(correlationId, refId, requestMethod, requestUrl, requestBody, "BIZ")).Start();

                // Call MicroService
                serviceResult = await apiService.CallMicroService<T>();

                // Log Response
                int responseStatusCode = (int)serviceResult.StatusCode;
                string responseMessage = "";

                /* remove more error for ui */
                if (!serviceResult.IsSuccessStatusCode)
                {
                    responseMessage = $"Service:{serviceResult.RequestUri} | Message:[{(int)serviceResult.StatusCode} {serviceResult.StatusCode.ToString()}] : {serviceResult.ReturnMessage}";
                }
                else
                {
                    responseMessage = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
                }

                new Thread(() => _ = _logService.InsertLogResponse(correlationId, refId, responseStatusCode, responseMessage, "BIZ")).Start();
            }
            else
            {
                ApiService apiService = new ApiService(GetMicroServiceHost(), url, request, true, accessToken, method, authenInfo);

                // Log Request
                string requestUrl = new Uri(new Uri(apiService.BaseAddress), apiService.RequestUri).AbsoluteUri;
                string requestBody = JsonConvert.SerializeObject(request);
                string requestMethod = method.ToString();
                new Thread(() => _ = _logService.InsertLogRequest(correlationId, refId, requestMethod, requestUrl, requestBody, "BIZ")).Start();

                // Call MicroService
                serviceResult = await apiService.CallMicroService<T>();

                // Log Response
                int responseStatusCode = (int)serviceResult.StatusCode;
                string responseMessage = ""; // !serviceResult.IsSuccessStatusCode ? serviceResult.ReturnMessage : await serviceResult.ResponseMessage.Content.ReadAsStringAsync();

                /* remove more error for ui */
                if (!serviceResult.IsSuccessStatusCode)
                {
                    responseMessage = $"Service:{serviceResult.RequestUri} | Message:[{(int)serviceResult.StatusCode} {serviceResult.StatusCode.ToString()}] : {serviceResult.ReturnMessage}";
                }
                else
                {
                    responseMessage = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
                }

                new Thread(() => _ = _logService.InsertLogResponse(correlationId, refId, responseStatusCode, responseMessage, "BIZ")).Start();
            }

            return serviceResult;
        }
        public async Task<ApiServiceResponseModel<T>> CallServiceA<T>(ServiceaRequestModel request)
        {
            string url = "/beginTransaction2";
            return await SendToServicea<T>(url, request, APIServiceMethod.POST);
        }
        public async Task<ServiceaResponseModel<T>> CheckResultHisun<T>(ApiServiceResponseModel<T> serviceResult)
        {
            if (!serviceResult.IsSuccessStatusCode) throw new ArgumentException(serviceResult.ReturnMessage);
            if (serviceResult.Entity == null) throw new ArgumentException($"Service : {serviceResult.RequestUri} | Message : {serviceResult.ReturnMessage}");
            return serviceResult.Entity?.DS;
        }
    }
}
