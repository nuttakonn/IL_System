﻿using ILSCREEN_BIZ_API.Common;
using ILSCREEN_BIZ_API.Models;
using ILSCREEN_BIZ_API.Models.Common;
using JackWFinlay.Jsonize;
using Newtonsoft.Json.Linq;

namespace ILSCREEN_BIZ_API.Services.Common
{
    public class CheckService
    {
        public async Task<Tuple<ResponseModel, string, string, string, string>> CallHealthCheckAsync(MicroServicesModel service)
        {
            ResponseModel response;
            try
            {

                using var client = new HttpClient();
                using HttpResponseMessage respMessage = await client.GetAsync(service.host);
                if (!respMessage.ToString().Contains("StatusCode: 200")) throw new Exception();
                using HttpContent content = respMessage.Content;
                var html = await content.ReadAsStringAsync();
                Jsonize jsonizer = new Jsonize(html);
                var jstr = jsonizer.ParseHtmlAsJsonString();
                JObject jobj = JObject.Parse(jstr);

                string version = service.name == "SMSFLAGAPI" ? (string)jobj?.Descendants()?.OfType<JProperty>()?
                                .FirstOrDefault(p => p.Name == "text" && p.Value.ToString().Contains("Version"))?.Value : (string)jobj.Descendants().OfType<JProperty>()
                                .FirstOrDefault(p => p.Name == "text" && p.Value.ToString().Contains("Version:"))?.Value;

                version = version?.Replace("Version:", string.Empty)?.Trim();

                string ip = (string)jobj.Descendants().OfType<JProperty>()
                                                                        .FirstOrDefault(p => p.Name == "text" && p.Value.ToString().Contains("IP:"))?.Value;
                ip = ip?.Replace("IP:", string.Empty)?.Trim();

                string apiPath = "";

                if (service.name == "TOKEN_API")
                    apiPath = "/api/HealthCheck/APIHealthCheck";
                //else if (service.name == "ITAASAPI")
                //    apiPath = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "localhost" ? "/api/HealthCheck/APIHealthCheck" : "/HealthCheck/APIHealthCheck";
                else apiPath = "/api/HealthCheck";


                ApiService api = new ApiService(service.host, apiPath, null, false, null, APIServiceMethod.GET, "");
                response = await api.Call<object>();
                if (response.success)
                {
                    response.message = $"Connect to {service.name} success.";
                    return Tuple.Create(response, service.host, service.name, ip, version);
                }

                response.message = $"Can connect to {service.name} but there is no response.";

                return Tuple.Create(response, service.host, service.name, ip, version);
            }
            catch (Exception ex)
            {
                return Tuple.Create(new ResponseModel() { status = 500, success = false, message = $"Can't connect to {service.name}. Exception {ex.Message}" }, service.host, service.name, string.Empty, string.Empty);
            }
        }
    }
}
