﻿using ILSCREEN_BIZ_API.Common;
using ILSCREEN_BIZ_API.Models;
using JackWFinlay.Jsonize;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Text;

namespace ILSCREEN_BIZ_API.Services.Common
{
    public class ApiService
    {
        public string BaseAddress { get; set; }
        public string RequestUri { get; set; }
        public object Parameter { get; set; }
        public bool UseTokenJwt { set; get; }
        public string AccessToken { get; set; }
        public string AccessKey { get; set; }
        public APIServiceMethod Method { set; get; }
        public bool HtmlConvert { set; get; }
        public ApiService(string baseAddress, string requestUri, object parameter, bool useTokenJwt, string accessToken, APIServiceMethod method, string accessKey)
        {
            this.BaseAddress = baseAddress;
            this.RequestUri = requestUri;
            this.Parameter = parameter;
            this.UseTokenJwt = useTokenJwt;
            this.Method = method;
            this.AccessToken = accessToken;
            this.AccessKey = accessKey;
        }


        public async Task<ApiServiceResponseModel<T>> CallMicroService<T>()
        {
            ApiServiceResponseModel<T> serviceResult = new ApiServiceResponseModel<T>();
            try
            {
                serviceResult.RequestUri = new Uri(BaseAddress + RequestUri);
                string json = JsonConvert.SerializeObject(Parameter);
                serviceResult.Content = new StringContent(json, Encoding.UTF8, "application/json");

                using (HttpClient client = new HttpClient())
                {
                    if (this.UseTokenJwt)
                    {
                        client.DefaultRequestHeaders.Add("Authorization", this.AccessToken ?? "jwt");
                    }
                    if (!string.IsNullOrEmpty(AccessKey))
                    {
                        client.DefaultRequestHeaders.Add("AccessKey", AccessKey ?? "");
                    }

                    serviceResult.StartWatch();
                    switch (this.Method)
                    {
                        case APIServiceMethod.GET:
                            serviceResult.ResponseMessage = await client.GetAsync(serviceResult.RequestUri).ConfigureAwait(false);
                            break;
                        case APIServiceMethod.POST:
                            serviceResult.ResponseMessage = await client.PostAsync(serviceResult.RequestUri, serviceResult.Content).ConfigureAwait(false);
                            break;
                        case APIServiceMethod.PUT:
                            serviceResult.ResponseMessage = await client.PutAsync(serviceResult.RequestUri, serviceResult.Content).ConfigureAwait(false);
                            break;
                        case APIServiceMethod.DELETE:
                            serviceResult.ResponseMessage = await client.DeleteAsync(serviceResult.RequestUri).ConfigureAwait(false);
                            break;
                        default:
                            throw new Exception("Api service method is not match with config");
                    }
                    serviceResult.StopWatch();
                    serviceResult.IsSuccessStatusCode = serviceResult.ResponseMessage.IsSuccessStatusCode;
                    serviceResult.StatusCode = serviceResult.ResponseMessage.StatusCode;

                    if (!serviceResult.IsSuccessStatusCode)
                    {

                        /* remove more error for ui */
                        string responseString = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
                        //var mediaTypeIsJson = serviceResult.ResponseMessage.Content.Headers.ContentType.MediaType == "application/json" ? true : false;
                        if (IsValidJson(responseString, out T obj))
                        {
                            var response = obj?.ConvertToModel<ResponseModel>();
                            serviceResult.ReturnMessage = response?.message ?? "";
                        }
                        else
                        {
                            Jsonize jsonizer = new Jsonize(responseString);
                            var jstr = jsonizer.ParseHtmlAsJsonString();
                            JObject jobj = JObject.Parse(jstr);
                            string javaException = jobj.Descendants().OfType<JProperty>().ToList().Find(p => p.Name == "text" && p.Value.ToString().Contains("java.lang.RuntimeException:"))?.Value.ToString()?.Replace("java.lang.RuntimeException:", string.Empty)?.Replace("program:", "Program: ").Trim();
                            serviceResult.ReturnMessage = javaException;
                        }
                        /* remove more error for ui */
                        //string responseString = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
                        //var obj = JsonConvert.DeserializeObject<T>(responseString);
                        //var response = obj?.ConvertToModel<ResponseModel>();
                        //serviceResult.ReturnMessage = response?.message ?? "";
                    }
                    else
                    {
                        string responseString = await serviceResult.ResponseMessage.Content.ReadAsStringAsync();
                        if (responseString.IndexOf('\"') == 0) responseString = JsonConvert.DeserializeObject<string>(responseString);
                        serviceResult.Entity = JsonConvert.DeserializeObject<T>(responseString);
                    }
                }
            }
            catch (Exception ex)
            {
                serviceResult.StopWatch();
                serviceResult.IsSuccessStatusCode = false;
                serviceResult.StatusCode = HttpStatusCode.BadRequest;
                serviceResult.ReturnMessage = $"{ex.Message} - {ex.InnerException}";
            }
            return serviceResult;
        }

        public async Task<ResponseModel> Call<T>(bool needValue = false)
        {
            if (this.UseTokenJwt && string.IsNullOrEmpty(this.AccessToken))
            {
                throw new Exception("Not found TokenService for generate Token.");
            }

            var respNew = await CallMicroService<T>().ConfigureAwait(false);
            var response = respNew.Entity != null ? respNew.Entity.ConvertToModel<ResponseModel>() : new ResponseModel();
            if (response == null)
            {
                if (needValue == true)
                {
                    throw new Exception("Empty value API: " + this.BaseAddress);
                }
                else
                {
                    response = new ResponseModel();
                }
            }
            if (response.data != null)
            {
                if (this.HtmlConvert == true)
                {
                    return response;
                }
                response.data = ((JContainer)response.data).ToObject<T>();
            }

            return response;
        }
        private bool IsValidJson<T>(string value, out T jsonData)
        {
            try
            {
                jsonData = JContainer.Parse(value).ToObject<T>();
                return true;
            }
            catch
            {
                jsonData = default(T);
                return false;
            }
        }
    }
}
