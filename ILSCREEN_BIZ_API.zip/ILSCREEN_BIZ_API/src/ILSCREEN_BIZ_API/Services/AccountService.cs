﻿using ILSCREEN_BIZ_API.Common;
using ILSCREEN_BIZ_API.Models;
using ILSCREEN_BIZ_API.Services.Interfaces;
using ILSCREEN_BIZ_API.Services.MicroServices.Interface;
using Newtonsoft.Json;

namespace ILSCREEN_BIZ_API.Services
{
    public class AccountService : IAccountService
    {
        private readonly IILScreenMsSqlMicroService _ilMS;
        public AccountService(IILScreenMsSqlMicroService ilMS)
        {
            _ilMS = ilMS;
        }

        public async Task<ResponseModel> GetViewVendorMaster(string searchBy, string searchValue)
        {
            var serviceResult = await _ilMS.GetViewVendorMaster<ResponseModel>(searchBy, searchValue);
            return Extensions.ConvertToModel<ResponseModel>(serviceResult.Entity);
        }
    }
}
