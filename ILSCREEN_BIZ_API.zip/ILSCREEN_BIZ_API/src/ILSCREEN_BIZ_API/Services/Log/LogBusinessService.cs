﻿using ILSCREEN_BIZ_API.Common;
using ILSCREEN_BIZ_API.Models;
using ILSCREEN_BIZ_API.Models.Common;
using ILSCREEN_BIZ_API.Services.Common;
using System.Net;

namespace ILSCREEN_BIZ_API.Services.Log
{
    public class LogBusinessService
    {
        protected bool _isEnable;
        public LogBusinessService()
        {
            _isEnable = bool.Parse(AppSetting.Configuration["Logging:Enable"] ?? "false");
        }
        public MicroServicesModel GetMicroServiceHost()
        {
            string name = "RECEIVEWITHDRAW_LOG_API";
            return AppSetting.MicroServices()?.Find(x => (x.name ?? "").ToUpper().Equals(name?.ToUpper())) ?? new MicroServicesModel();
        }

        public async Task InsertItem(LogApiModel entity, RefType requestORresponse)
        {
            try
            {
                if (!_isEnable) return;
                string url = string.Empty;
                ResponseModel response = new ResponseModel();
                if (requestORresponse == RefType.REQUEST) url = "/api/LogAPI/AddLogRequest";
                else if (requestORresponse == RefType.RESPONSE) url = "/api/LogAPI/AddLogResponse";

                ApiService apiService = new ApiService(GetMicroServiceHost().host ?? "", url, entity, false, string.Empty, APIServiceMethod.POST, "");
                response = await apiService.Call<object>();
                if (!response.success)
                {
                    throw new Exception($"ไม่สามารถเชื่อต่อ API {GetMicroServiceHost().name} ได้ กรุณาติดต่อผู้ดูแลระบบ");
                }
            }
            catch
            {
                //
            }
        }

        public async Task InsertLogRequest(string correlationId, string refId, string requestMethod, string requestUrl, string requestBody, string createBy)
        {
            var logRequest = new LogApiModel()
            {
                correlationId = correlationId,
                refId = refId,
                refType = RefType.REQUEST.ToString(),
                requestMethod = requestMethod,
                requestUrl = requestUrl,
                requestBody = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Production" ? requestBody.PBKDF2Encrypt() : requestBody,
                ipAddress = Dns.GetHostName(),
                createBy = createBy,
                createDate = DateTime.Now
            };

            await InsertItem(logRequest, RefType.REQUEST);
        }

        public async Task InsertLogResponse(string correlationId, string refId, int responseStatusCode, string responseMessage, string createBy)
        {
            var logResponse = new LogApiModel()
            {
                correlationId = correlationId,
                refId = refId,
                refType = RefType.RESPONSE.ToString(),
                responseStatusCode = responseStatusCode,
                responseMessage = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Production" ? responseMessage.PBKDF2Encrypt() : responseMessage,
                ipAddress = Dns.GetHostName(),
                createBy = createBy,
                createDate = DateTime.Now
            };

            await InsertItem(logResponse, RefType.RESPONSE);
        }
    }
}
