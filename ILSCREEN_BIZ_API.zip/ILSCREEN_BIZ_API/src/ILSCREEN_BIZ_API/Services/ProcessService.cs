﻿using Azure;
using ILSCREEN_BIZ_API.Common;
using ILSCREEN_BIZ_API.Models;
using ILSCREEN_BIZ_API.Models.Common;
using ILSCREEN_BIZ_API.Services.Interfaces;
using ILSCREEN_BIZ_API.Services.MicroServices.Interface;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Data;
using System.Net;

namespace ILSCREEN_BIZ_API.Services
{
    public class ProcessService : IProcessService
    {
        private readonly IILScreenMsSqlMicroService _ilMS;
        private readonly IServiceaMicroService _sera;
        public ProcessService(IILScreenMsSqlMicroService ilMS, IServiceaMicroService sera)
        {
            _ilMS = ilMS;
            _sera = sera;
        }

        public async Task<ResponseModel> GetMonitorCaseUnsign(string vendor)
        {
            try
            {
                var serviceResult = await _ilMS.GetMonitorCaseUnsign<ResponseModel>(vendor);
                var isNotFound = serviceResult?.StatusCode == HttpStatusCode.NotFound;

                if (serviceResult?.Entity != null)
                {
                    return Extensions.ConvertToModel<ResponseModel>(serviceResult.Entity);
                }

                if (isNotFound)
                {
                    return new ResponseModel
                    {
                        success = true,
                        message = serviceResult?.ReturnMessage?.ToString() ?? "Data not found.",
                        data = new List<object>()
                    };
                }
                return new ResponseModel
                {
                    success = false,
                    message = serviceResult?.ReturnMessage?.ToString() ?? "Internal error occurred.",
                    data = null
                };
            }
            catch (Exception ex) 
            {
                return new ResponseModel
                {
                    success = false,
                    message = ex.Message.ToString(),
                    data = null
                };
            }
        }
        public async Task<ResponseModel> GetVendorListMonitorCaseUnsign()
        {
            try
            {
                var serviceResult = await _ilMS.GetVendorListMonitorCaseUnsign<ResponseModel>();
                var isNotFound = serviceResult?.StatusCode == HttpStatusCode.NotFound;

                if (serviceResult?.Entity != null)
                {
                    return Extensions.ConvertToModel<ResponseModel>(serviceResult.Entity);
                }

                if (isNotFound)
                {
                    return new ResponseModel
                    {
                        success = true,
                        message = serviceResult?.ReturnMessage?.ToString() ?? "Data not found.",
                        data = new List<object>()
                    };
                }

                return new ResponseModel
                {
                    success = false,
                    message = serviceResult?.ReturnMessage?.ToString() ?? "Internal error occurred.",
                    data = null
                };
            }
            catch (Exception ex) 
            {
                return new ResponseModel
                {
                    success = false,
                    message = ex.Message.ToString(),
                    data = null
                };
            }
        }

        public async Task<ResponseModel> CalculateInstallmentMonitorCaseUnsign(string contract, string appno)
        {
            try
            {
                var request = new ServiceaRequestModel()
                {
                    TIA = new List<string> { "01", "YMD", "" },
                    PROGRAM = "ILSR97",
                    AppName = "IL"
                };

                var serviceResult = await _sera.CallServiceA<ResponseModel>(request);
                var result = await _sera.CheckResultHisun<ServiceaResponseModel>(serviceResult);
                if (!serviceResult.IsSuccessStatusCode || serviceResult.Entity == null)
                {
                    return new ResponseModel
                    {
                        success = false,
                        message = "Call to ServiceA failed",
                        data = null
                    };
                }

                return new ResponseModel
                {
                    success = true,
                    message = "Success",
                    data = serviceResult.Entity
                };
            }
            catch (Exception ex)
            {
                return new ResponseModel
                {
                    success = false,
                    message = ex.Message,
                    data = null
                };
            }
        }

    }
}
